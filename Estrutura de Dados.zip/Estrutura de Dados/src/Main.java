import encadeamento.Lista;
import entidades.No;

public class Main {
    public static void main(String[] args) {














        Pilha pilhaTeste = new Pilha(4);

        pilhaTeste.empilhar(2);
        pilhaTeste.empilhar(3);
        pilhaTeste.empilhar(7);
        pilhaTeste.empilhar(8);
        pilhaTeste.empilhar(5);
        pilhaTeste.exibir();
        pilhaTeste.desempilhar();
        pilhaTeste.desempilhar();
        pilhaTeste.desempilhar();
        pilhaTeste.empilhar(5);
        pilhaTeste.exibir();

        /**Fila fila = new Fila(5);

        fila.enfileirar(2);
        fila.enfileirar(4);
        fila.enfileirar(3);
        fila.enfileirar(5);
        fila.enfileirar(7);
        fila.exibir();
        fila.desenfileirar(2);
        fila.exibir();
        System.out.print("Está vazio? "+fila.estaVazia());

        fila.enfileirar(3);
        fila.enfileirar(7);
        fila.enfileirar(200);

        fila.desenfileirar();
        fila.desenfileirar();

        fila.enfileirar(5);
        fila.enfileirar(10);

        fila.exibir();*/
    }
}