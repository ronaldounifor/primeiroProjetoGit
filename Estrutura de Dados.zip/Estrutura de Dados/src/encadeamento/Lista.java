package encadeamento;

import entidades.No;

public class Lista {

    private No primeiroElemento;
    private int quantidade;

//    Criar uma nova lista – Lista()
    public Lista() {
        primeiroElemento = null;
        quantidade = 0;
    }

//    Retornar a quantidade de elementos – getQuantidade()
    public int getQuantidade() {
        return quantidade;
    }

//    Verificar se a lista está vazia – estaVazia()
    public boolean estaVazia() {
        return quantidade == 0;
    }

//    Inserir um elemento e na posição i – adicionarPosicao(e, i)
    public void adicionarPosicao(int elemento, int posicao) {
        No elementoAux = new No(elemento);
        //FIXME
        No elementoAnterior = primeiroElemento;
        for (int i = 1; i < posicao; i++)
            elementoAnterior = elementoAnterior.getProximo();

        //TODO atualizar valores para próximos
        elementoAnterior.setProximo(elementoAux);

        quantidade++;
    }

//    Inserir um elemento e no início – adicionarInicio(e)
    public void adicionarInicio(int elemento) {
        No elementoAux = new No(elemento);

        elementoAux.setProximo(primeiroElemento);
        primeiroElemento = elementoAux;
        quantidade++;
    }

//    Inserir um elemento e no final – adicionarFinal(e)
    public void adicionarFinal(int elemento) {
        No elementoAux = new No(elemento);

        No ultimoElemento = primeiroElemento;
        for (int i = 1; i < quantidade; i++)
            ultimoElemento = ultimoElemento.getProximo();

        ultimoElemento.setProximo(elementoAux);

        quantidade++;
    }

//    Acessar o elemento na posição i – retornarElemento(i)
//    Remover o elemento e na posição i – removerPosicao(i)
//    Remover o elemento no inicio – removerInicio(i)
//    Remover o elemento no final – removerFinal(i)

}
