import javax.swing.*;

public class Pilha {
    private int elementos[];
    private int quantidade;
    private int posicaoUltimo;
    private int limite;

    //Criar uma nova pilha – Pilha()
    public Pilha() {
        limite = 10;
        elementos = new int[limite];
        quantidade = 0;
        posicaoUltimo = -1;
    }

    public Pilha(int limite) {
        this.limite = limite;
        elementos = new int[limite];
        quantidade = 0;
        posicaoUltimo = -1;
    }

    //Verificar se a pilha está vazia – estaVazia()
    public boolean estaVazia(){
        if (quantidade == 0)
            return true;
        else
            return false;
    }

    //Verificar se a pilha está cheia, caso exista um limite – estaCheia()
    public boolean estaCheia(){
        if (quantidade == limite)
            return true;
        else
            return false;
    }

    //Retornar a quantidade de elementos – getQuantidade()
    public int getQuantidade() {
        return quantidade;
    }

    //Acessar o elemento no topo da pilha – retornarElemento()
    public int retornarElemento() {
        return elementos[posicaoUltimo];
    }

    //Inserir um elemento e no topo da pilha – empilhar(e)
    public void empilhar(int elemento) {
        if(!estaCheia()) {
            elementos[quantidade] = elemento;
            quantidade++;
            posicaoUltimo++;
        }
    }

    //Remover o elemento e no topo da pilha – desempilhar()
    public int desempilhar() {
        if(!estaVazia()) {
            int elementoRemovido = elementos[posicaoUltimo];
            quantidade--;
            posicaoUltimo--;

            return elementoRemovido;
        }

        return -1;
    }

    public void exibir(){
        String elementos = "";
        for (int i = posicaoUltimo; i >= 0; i--)
            elementos += this.elementos[i] + "\n";

        JOptionPane.showMessageDialog(null, elementos);
    }
}