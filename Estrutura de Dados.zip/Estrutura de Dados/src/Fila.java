import javax.swing.*;

public class Fila{
    int primeiroElemento;
    int ultimoElemento;
    int limite;
    int quantidade;
    int elementos[];

    public Fila(){
        primeiroElemento = ultimoElemento = -1;
        limite = 10;
        elementos = new int[limite];
        quantidade = 0;
    }

    public Fila(int limite){
        primeiroElemento = ultimoElemento = -1;
        this.limite = limite;
        elementos = new int[limite];
        quantidade = 0;
    }

    public boolean estaVazia(){
        if (quantidade == 0)
            return true;
        else
            return false;
    }

    public boolean estaCheia(){
        if (quantidade == limite)
            return true;
        else
            return false;
    }

    public void enfileirar(int novoElemento){
        if (!estaCheia() && !estaNaFila(novoElemento)){
            if (primeiroElemento == -1)
                primeiroElemento = 0;
            ultimoElemento++;
            elementos[ultimoElemento] = novoElemento;
            quantidade++;
        }
    }

    private boolean estaNaFila(int elemento) {
        for (int i = 0; i <= quantidade; i++) {
            if(elementos[i] == elemento)
                return true;
        }
        return false;
    }

    public void desenfileirar(){
        if (!estaVazia()){
            quantidade--;

            for (int i = 0; i < quantidade; i++) {
                elementos[i] = elementos[i + 1];
            }

            ultimoElemento--;
        }
    }

    public void desenfileirar(int qtdeRemovidos){
        if (!estaVazia() && (qtdeRemovidos <= quantidade) && qtdeRemovidos > 0){
            quantidade = quantidade - qtdeRemovidos;

            for (int i = 0; i < quantidade; i++) {
                elementos[i] = elementos[i + qtdeRemovidos];
            }

            ultimoElemento = ultimoElemento - qtdeRemovidos;
        }
    }

    public void exibir(){
        String elementos = "";
        for (int i = primeiroElemento; i <= ultimoElemento; i++) {
            if(i == ultimoElemento)
                elementos += this.elementos[i];
            else
                elementos += this.elementos[i]+ ", ";
        }

//        elementos = elementos + ". Quantidade: "+quantidade
//                +", Primeiro: "+primeiroElemento
//                +", Último: "+ultimoElemento
//                +", Limite: "+limite;
        JOptionPane.showMessageDialog(null, elementos);
    }
}