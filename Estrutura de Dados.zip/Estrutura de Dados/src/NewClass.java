import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class NewClass {
    public static void main(String[] args) {
        // 1 2 3 4 5
        Stack<String> pilha1 = new Stack<String>();
        Queue<String> fila1 = new LinkedList<String>();

        pilha1.add("Teste");

        fila1.add("Ceara");
        fila1.add("Fortaleza");
        fila1.add("Floresta");
        fila1.add("Ferroviario");
        fila1.add("Guarani");

        System.out.println(fila1);
        //removerCauda(fila1);
        invertaFilaUsandoPilha(fila1);
        System.out.println(fila1);
        /////

        System.out.println(fila1.poll());
        System.out.println(fila1.peek());
        System.out.println(fila1.peek());
        fila1.add(fila1.poll());
        fila1.add(fila1.poll());

        System.out.println(fila1);
        System.out.println(fila1.size());
        System.out.println(fila1.isEmpty());

        //FIXME: ultimos serao primeiros
        for(int i = 0; i < fila1.size()-1; i++) {
            fila1.add(fila1.poll());
        }

        // 1 2 3 4 5
        // 2 3 4 5 1
        // 3 4 5 1 2
        // 4 5 1 2 3
        // 5 1 2 3 4

        System.out.println(fila1);


        //System.out.println(fila1 + "\n Inverso\n");

        //invertaFilaUsandoPilha(fila1);

        // Imprimir fila ao contrario
        //System.out.println("\n Ao contrario\n");

        //imprimirFilaAoContrario(fila1);
        //System.out.println(fila1 + "\n\n");

        // Ultimos serão os primeiros
        //for(int i = 0; i < fila1.size()-1; i++) {
        //	fila1.add(fila1.poll());
        // }
        //System.out.println(fila1);

        //   2 3 1

        // usando apenas fila elimine o elemento da cauda (Final da Fila). poll() elimina da frente
        //TODO: Fazer a implementacao baseado no codigo acima // ultimos serao primeiros
        removerCauda(fila1);
        invertaFilaUsandoPilha(fila1);
        imprimirFilaAoContrario(fila1);
        inverterFilaUsandoApenasFila(fila1);
        // Pode usar duas filas auxiliares
        // Desafio: Fazer só com uma fila auxiliar
//
        String time = fila1.poll(); // desenfileirar
//		System.out.println(fila1.peek());
//		System.out.println("time: " + time);
//		System.out.println(fila1.size());
//		System.out.println(fila1.isEmpty());
    }

    // Só para imprimir fila ao contrário
    private static void imprimirFilaAoContrario(Queue<String> fila1) {
        System.out.println("\n\nA fila impressa ao contrário é: ");
        for(int j = 0;j < fila1.size();j++){
            //FIXME: Últimos serão os primeiros
            for(int i = 0;i < fila1.size()-1;i++){
                fila1.add(fila1.poll());
            }
            System.out.print(fila1.peek() + " ");
        }
    }

// 1 2 3 4 5
// 3 4 5 1 2

// ;;imprimir: 5 4 3

    // Treinar fila: inverter a fila usando só a estrutura de Fila
    private static void inverterFilaUsandoApenasFila(Queue<String> fila1) {
        Queue<String> filaInvertida = new LinkedList<String>();

        while (!fila1.isEmpty()) {
            //ultimos serão primeiros...
            for(int i = 0; i < fila1.size()-1; i++) {
                fila1.add(fila1.poll());
            }
            filaInvertida.add(fila1.poll());
        }
        while(!filaInvertida.isEmpty()) {
            fila1.add(filaInvertida.poll());
        }
    }

    //FIXME: Revisar esse código.
    private static void invertaFilaUsandoPilha(Queue<String> fila1) {
        Stack<String> pilha = new Stack<String>();
        // retirar elementos da fila e colocar na pilha
        while(!fila1.isEmpty()) {
            pilha.push(fila1.poll());
        }
        //retirar elementos da pilha e colocar na fila
        while(!pilha.isEmpty()) {
            fila1.add(pilha.pop());
        }
    }

    private static void removerCauda(Queue<String> fila1) {
        // tentar fazer esse exercício de fila...
        // 1 2 3 4 5
        // 5 1 2 3 4
        //FIXME: ultimos serao primeiros
        for(int i = 0; i < fila1.size()-1; i++) {
            fila1.add(fila1.poll());
        }
        fila1.poll();
    }

    // Fazer a implementação do clone de uma Fila
    private static Queue<String> clone(Queue<String> fila1) {
        Queue<String> clone = new LinkedList<String>();
        // TODO: Fazer a lógica para implementar o clone...


        return clone;
    }


}
